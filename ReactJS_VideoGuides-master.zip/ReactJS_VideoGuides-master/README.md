# ReactJS and Redux - Mastering Web Apps
"React JS and Redux - Mastering Web Apps": Official guide repo used to accompany video lessons.

This provides the completed projects for:
- countdownChamp
- goalCoach
- musicMaster
- reminderPro

Check out the original course: 
https://www.udemy.com/react-js-and-redux-mastering-web-apps/
