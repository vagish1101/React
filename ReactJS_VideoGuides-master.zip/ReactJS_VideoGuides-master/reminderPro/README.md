#reminderPro

This application introduces Redux. It goes over setting up the typical redux structure. It also features browser cookies.