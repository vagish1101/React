export const SIGNED_IN = 'SIGNED_IN';
export const SET_GOALS = 'SET_GOALS';
export const SET_COMPLETED = 'SET_COMPLETED';
